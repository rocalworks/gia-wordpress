<div id="optinforms-form6-container">

	<div id="optinforms-form6">

		<input type="text" id="optinforms-form6-email-field" placeholder="<?php echo do_shortcode( optinforms_form6_default_email_field() ); ?>" />
		<input type="button" id="optinforms-form6-button" value="<?php echo do_shortcode( optinforms_form6_default_button_text() ); ?>" />
	
	</div><!--optinforms-form6-->

</div><!--optinforms-form6-container-->

<div class="clear"></div>