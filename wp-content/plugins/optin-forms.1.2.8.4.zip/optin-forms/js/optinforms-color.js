jQuery(document).ready(function($){
	$('.optinforms-color').wpColorPicker();
});