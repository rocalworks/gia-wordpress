<?php

/*
Plugin Name: LiveReload
Description: Adds the JavaScript for LiveReload to a WordPress site
Version: 0.0.0.0.1alpha
Author: Peter Wilson
Author URI: http://peterwilson.cc/

*/



function pwcc_live_reload_js() {
	?>
	<script>document.write('<script src="http://' + (location.host || 'localhost').split(':')[0] + ':35729/livereload.js?snipver=1"></' + 'script>')</script>
	<?php
}
add_action('wp_footer', 'pwcc_live_reload_js')

?>