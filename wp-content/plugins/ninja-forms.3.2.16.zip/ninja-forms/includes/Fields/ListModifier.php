<?php //if ( ! defined( 'ABSPATH' ) ) exit;
//
///**
// * Class NF_Fields_ListModifier
// */
//class NF_Fields_ListModifier extends NF_Abstracts_List
//{
//    protected $_name = 'listmodifier';
//
//    protected $_type = 'listmodifier';
//
//    protected $_section = 'pricing';
//
//    protected $_templates = 'list';
//
//    public function __construct()
//    {
//        parent::__construct();
//
//        $this->_nicename = __( 'Modifier', 'ninja-forms' );
//    }
//}
